from django.apps import AppConfig


class InPortfolioConfig(AppConfig):
    name = 'in_portfolio'
